import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;
public class Deng2{
public static void main(String arg[]) {
		Login2 wiDenglu = new Login2();
		wiDenglu.ini();
	}
}