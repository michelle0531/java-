import java.awt.event.*;
import javax.swing.*;
import java.sql.*; 
import java.util.*;
public class LoginHandle2 implements ActionListener{
   Connection con =null;
   PreparedStatement sta = null;
   String SQL;
   JTextField xuehao;
   JPasswordField password;
   JFrame win;
public void setLogin(JFrame f){
   win=f;}
   LoginHandle2(){
     try { 
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        con=DriverManager.getConnection("jdbc:derby:GUOXUE;create=true");
     }
     catch(Exception exp){
       
     }
   }
 
   public void setJTextField(JTextField t){
      xuehao=t;
   }
   public void setJPasswordField(JPasswordField p){
      password=p;
   }
   public void actionPerformed(ActionEvent e) {

       if (e.getSource()==win.queButton){
      char [] mima= password.getPassword();
      String id= xuehao.getText();
      String keyword = new String(mima);
      keyword= keyword.trim();
      try{  
            String str="jdbc:derby:GUOXUE;create=true";
            con=DriverManager.getConnection(str);
            SQL="SELECT xuehao FROM users where xuehao='"+id+"'";
            sta =  con.prepareStatement(SQL);
            ResultSet rs = sta.executeQuery(); 
            boolean boo = rs.next();
            if(boo) {
              
               String pass=rs.getString(1);
               System.out.println(pass);
               if(keyword.equals(pass)){
                  ExamView view = new ExamView();
               }
               else {

                   JOptionPane.showMessageDialog
         (null,"�����","��Ϣ�Ի���", JOptionPane.WARNING_MESSAGE);

               }

            }
            else {
                JOptionPane.showMessageDialog
         (null,"�û�����","��Ϣ�Ի���", JOptionPane.WARNING_MESSAGE);
            }  

          
          con.close();
       }
       catch(Exception exp){
        JOptionPane.showMessageDialog
         (null,""+exp,"��Ϣ�Ի���", JOptionPane.WARNING_MESSAGE);
       }
     }
if(e.getSource()==win.chongButton){
      xuehao.setText("");
      password.setText("");}
if(e.getSource()==win.tuiButton){
      System.exit(0);
}
   }
}  
     
