import java.sql.*;
public class Day4_2 {
   public static void main(String[] args) {
      Connection con = null;
      PreparedStatement sta = null;
      String SQL;
      try { 
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        con=DriverManager.getConnection("jdbc:derby:GUOXUE;create=true");
      }
      catch(Exception e) {
        System.out.println(e);  
        return;
      }
      try {
          SQL="create table users "+
          "(xuehao char(10) primary key not null,xingming varchar(20)";
         sta = con.prepareStatement(SQL);
         sta.executeUpdate();//������biao
      }
      catch(SQLException e) {
         System.out.println("�ñ��Ѿ����ڣ��������´�����"); 
         //ɾ����,ִ��sta.execute("drop table users");
      }
      try {
         SQL = "insert into users values(?,?,?)";
         sta =  con.prepareStatement(SQL);
         sta.setString(1318180101,"����ǿ");
      
         
         sta.executeUpdate();
       
         SQL = "SELECT * FROM users";
         sta =  con.prepareStatement(SQL);
         ResultSet rs = sta.executeQuery(); 
         while(rs.next()) {
            String xuehao=rs.getString(1318180101);
            System.out.print(xuehao+"\t");
         
         }
         con.close();
      } 
      catch(SQLException e) {
          System.out.println(e);  
      }
  }
}


