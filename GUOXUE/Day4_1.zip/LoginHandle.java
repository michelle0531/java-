import java.awt.event.*;
import javax.swing.*;
import java.sql.*; 
import java.util.*;
public class LoginHandle implements ActionListener{
   Connection con =null;
   PreparedStatement sta = null;
   String SQL;
   Login log;
   JTextField adminField;
   JPasswordField password;
   LoginHandle(){
     try { 
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        con=DriverManager.getConnection("jdbc:derby:GUOXUE;create=true");
     }
     catch(Exception exp){
       
     }
   }
 
 public void setLogin(Login L){
      log=L;
   }

public void actionPerformed(ActionEvent e) {


     if(e.getSource()==log.queButton)
    {
     

      char [] mima= password.getPassword();
      String id= password.getText();
      String keyword = new String(mima);
      keyword= keyword.trim();
      try{  
            String str="jdbc:derby:GUOXUE;create=true";
            con=DriverManager.getConnection(str);
            SQL="SELECT xuehao FROM Students where xuehao='"+id+"'";
            sta =  con.prepareStatement(SQL);
            ResultSet rs = sta.executeQuery(); 
            boolean boo = rs.next();
            if(boo) {
              
               String pass=rs.getString(1);
               System.out.println(pass);
               if(keyword.equals(pass)){
                  ExamView view = new ExamView();
               }
               else {

                   JOptionPane.showMessageDialog
         (null,"�����","��Ϣ�Ի���", JOptionPane.WARNING_MESSAGE);

               }

            }
            else {
                JOptionPane.showMessageDialog
         (null,"�û�����","��Ϣ�Ի���", JOptionPane.WARNING_MESSAGE);
            }  

          
          con.close();
       }
      catch(Exception exp){
        JOptionPane.showMessageDialog
         (null,""+exp,"��Ϣ�Ի���", JOptionPane.WARNING_MESSAGE);
         }

       }
  if(e.getSource()==log.chongButton){
      adminField.setText("");
      password.setText("");
      }
if(e.getSource()==log.tuiButton){
      System.exit(0);
     }

      
   }
}  
     
