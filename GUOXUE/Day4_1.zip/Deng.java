import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;
public class Deng{
public static void main(String arg[]) {
		Login wiDenglu = new Login();
		wiDenglu.ini();
	}
}