import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;
public class Deng3{
public static void main(String arg[]) {
		Login3 wiDenglu = new Login3();
		wiDenglu.ini();
	}
}