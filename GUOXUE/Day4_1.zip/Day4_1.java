import java.sql.*;
public class Day4_1 {
   public static void main(String[] args) {
      Connection con = null;
      Statement sta = null;
      String SQL=null;
      try { 
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        con=DriverManager.getConnection("jdbc:derby:GUOXUE;create=false");
      }
      catch(Exception e) {
        System.out.println(e);  
        return;
      }
      try {
          sta = con.createStatement();
          SQL="create table users "+
           " (xuehao char(10) primary key,pwl varchar(10))";
          sta.executeUpdate(SQL);//������
         
      }
      catch(SQLException e) {
         System.out.println("�ñ��Ѿ����ڣ��������´�����"); 
         //ɾ����,ִ��sta.execute("drop table users");
      }
      try {
         ResultSet rs = sta.executeQuery("SELECT * FROM users "); 
         while(rs.next()) {
            String xuehao=rs.getString(1);
           
            String pwl=rs.getString(2);
            System.out.println(xuehao+"\t"+pwl);
           
         }
         con.close();
      } 
      catch(SQLException e) {
          System.out.println(e);  
      }
  }
}

