import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;
public class Login1 {
        JFrame win = new JFrame("��ѧ����ϵͳ��¼");
	JLabel dJLabel[] = new JLabel[3];
	JLabel adminJLabel = new JLabel("������");
	JTextField adminField = new JTextField();
	JLabel passJLabel = new JLabel("ѧ�ţ�");
	JPasswordField password = new JPasswordField();
	JButton queButton = new JButton("��¼");

	JButton chongButton = new JButton("����");
	JButton tuiButton = new JButton("�˳�");
	Font font3 = new Font("����", Font.BOLD, 20);
	Font font4 = new Font("����", Font.BOLD, 15);
	Timer time1 = new Timer();// ��ʱ��
	JLabel shijianJLabel = new JLabel("");
     
        LoginHandle1 handle;

	void ini() {
		win.setVisible(true);
		win.setSize(350, 300);
                
		win.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		win.setAlwaysOnTop(true);
		win.setLocation(500, 200);
		win.setResizable(false);    // ��ѧ����
		URL urlm = getClass().getResource("logo.png");
		ImageIcon imgm = new ImageIcon(urlm);
		Image img4 = imgm.getImage();
		ImageIcon smallIcon = new ImageIcon(img4.getScaledInstance(220,70,Image.SCALE_FAST));
		dJLabel [0] = new JLabel();
		dJLabel [0].setIcon(smallIcon); 
                // ����
		URL url1 = getClass().getResource("bg_1.jpg");
		ImageIcon img1 = new ImageIcon(url1);
		Image img2 = img1.getImage();
		ImageIcon smallIcon1 = new ImageIcon(img2.getScaledInstance(350, 300,Image.SCALE_FAST));
		dJLabel[1] = new JLabel();
		dJLabel[1].setIcon(smallIcon1);
                // ��������
		adminJLabel.setFont(font3);
		passJLabel.setFont(font3);
		shijianJLabel.setFont(font4);
		// ����
		win.setLayout(null);
		win.add(shijianJLabel);
		win.add(adminJLabel);
		win.add(adminField);
		win.add(passJLabel);
		win.add(password);
		win.add(queButton);
		win.add(chongButton);
		win.add(tuiButton);
		win.add(dJLabel[0]);
		win.add(dJLabel[1]);

		shijianJLabel.setBounds(30, 220, 300, 30);
		tuiButton.setBounds(230, 185, 60, 30);
		chongButton.setBounds(140, 185, 60, 30);
		queButton.setBounds(50, 185, 60, 30);
		password.setBounds(120, 125, 150, 30);
		passJLabel.setBounds(50, 125, 70, 30);
		adminField.setBounds(120, 90, 150, 30);
		adminJLabel.setBounds(50, 90, 70, 30);
		dJLabel[0].setBounds(65, 10, 230, 70);
		dJLabel[1].setBounds(0, 0, 350, 300);

                handle= new  LoginHandle2();
                queButton.addActionListener(handle);
                chongButton.addActionListener(handle);
                tuiButton.addActionListener(handle);
                
		time1.schedule(new TimerTask() {// ��ʱ��
		 public void run() {

		  String weekwen = null;
                  Calendar now1 = new GregorianCalendar(); // ��õ�ǰ������ʱ�����
		 int hour = now1.get(Calendar.HOUR_OF_DAY); // Сʱ����õ�ǰ��ʱ��
	       	int minute = now1.get(Calendar.MINUTE); // �֣�ͬ��
		int second = now1.get(Calendar.SECOND); // ��
		int year = now1.get(Calendar.YEAR);
		int month = now1.get(Calendar.MONTH) + 1;
		int day = now1.get(Calendar.DATE);
		int week = now1.get(Calendar.DAY_OF_WEEK); // ����

		switch (week) {
				case 2:
					weekwen = "����һ";
					break;
				case 3:
				        weekwen = "���ڶ�";
					break;
				case 4:
					weekwen = "������";
					break;
				case 5:
					weekwen = "������";
					break;
				case 6:
					weekwen = "������";
					break;
				case 7:
					weekwen = "������";
					break;
				case 1:
					weekwen = "������";
					break;
						}
			shijianJLabel.setText(year + "��" + nd(month) + "��"
					    + nd(day) + "��" + "  " + nd(hour) + ":"
					    + nd(minute) + ":" + nd(second) + "  "
					    + weekwen);
				}
		}, 1000, 500);
	}

	String nd(int m) {
		if (m < 10)
			return ("0" + Integer.toString(m));
		else {
			return (Integer.toString(m));
		}
	}

   }
               
